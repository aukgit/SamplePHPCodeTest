<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>L5 : Validate Password</title>

    <link rel="stylesheet" href="normalize.css" type="text/css" />
    <link rel="stylesheet" href="style.css" type="text/css" />
</head>
<?php 

if ($_POST != null) {
        //save into database.
        //echo "</br><pre>" ;print_r( $_POST ) ;echo "</pre></br>" ; die(); 
        //Global $Connection;
    $pass = $_POST["Password"];
    $confirmPassword = $_POST["ConfirmPassword"];


}

function lenCheck($validatorArray ,$password){

}

function isAlhpa($password){
    
}

function isPresent($str, $arr){
    $len = strlen($arr);

    for ($i=0; $i < $len ; $i++) { 
        $item = $arr[$i];
        if(strpos($str, $item) >= 0){
            return true;
        }
    }

    return false;
}

function anyNumberPresent($password){
    $arr = array(0,1,2,3,4,5,6,7,8,9);

}

function validatePassword($password){
       
   
}

?>


<body>
    <div class="page">
    <form action="p3.php" method="post">
        <label>Password : </label>     <br />
        <input type="text" name="Password" placeholder="Password" style="display:block; width:500px;height:25px;" width="500px"/> <br />
        <label>Confirm Password : </label>     <br />
        <input type="text" name="ConfirmPassword" placeholder="ConfirmPassword" style="display:block; width:500px;height:25px;" width="500px"/> <br />
       
        <input type="submit" value="Save"/>
    </form>

    </div>


    <script type="text/javascript" src="script.js"></script>
</body>

</html>